# WTG Wartungsplaner – Prototyp

Plant die Wartungstermine der Techniker aus der Access-Datenbank (WTG_Plan) und Lukas' Zeitliste,
bildet Touren nach Nähe (OpenStreetMap) und trägt die Termine auf Wunsch direkt in Outlook ein.

> **Wichtig:** Dieses Repository enthält nur das Programm – **keine Kundendaten, keine Passwörter**.
> Die Access-Datei, die Excel-Liste und `config.lokal.php` legt jeder nur bei sich ab (siehe `.gitignore`).
> Das Repository bitte **privat** lassen.

GitHub speichert nur den Code, es führt die App nicht aus. Getestet wird auf dem eigenen Rechner
unter `http://localhost:8000`.

---

## 1. Herunterladen

Auf GitHub oben **Code → Download ZIP**, entpacken – unter Windows z. B. nach `C:\WTG-Wartungsplaner`,
auf dem Mac in den Benutzerordner (siehe Abschnitt 3).
Wer Git nutzt: `git clone …` – Updates dann mit `git pull`.

> Windows kann beim ersten Doppelklick auf eine `.bat` warnen („Der Computer wurde durch Windows geschützt“).
> Dann **Weitere Informationen → Trotzdem ausführen**. Alternativ vor dem Entpacken:
> Rechtsklick auf die ZIP → Eigenschaften → „Zulassen“ anhaken.

## 2. Windows einrichten (einmalig)

1. **PHP** (8.2 oder neuer, „VS16 x64 Non Thread Safe“, ZIP) von <https://windows.php.net/download/> laden
   und nach `C:\php` entpacken, sodass es `C:\php\php.exe` gibt.
2. In `C:\php` die Datei `php.ini-production` kopieren und die Kopie `php.ini` nennen.
   Mit dem Editor öffnen und bei diesen Zeilen das `;` am Anfang entfernen:
   ```ini
   extension_dir = "ext"
   extension=curl
   extension=mbstring
   extension=openssl
   extension=pdo_odbc
   extension=pdo_sqlite
   extension=zip
   ```
3. **Access-Treiber:** Ist Microsoft Access (64-Bit) installiert, ist er schon da. Sonst die
   *Microsoft Access Database Engine 2016 Redistributable* (**x64**) installieren.
   Ist ein 32-Bit-Office installiert, lehnt das Setup ab – dann in der Eingabeaufforderung
   `accessdatabaseengine_X64.exe /quiet` ausführen.
   Prüfen: `C:\php\php.exe -r "print_r(PDO::getAvailableDrivers());"` muss `odbc` und `sqlite` zeigen.
4. Die Access-Datei (`WTG_Plan.accdb`) und Lukas' Excel-Liste in den Ordner **`Import`** legen.
5. **`1_Einrichten.bat`** doppelklicken. Importiert die Daten und sucht die Adressen auf der Karte
   (ca. 10 Minuten, 1 Adresse pro Sekunde – Vorgabe von OpenStreetMap).
6. **`2_Starten.bat`** doppelklicken → der Browser öffnet `http://localhost:8000`.
   Anmelden z. B. mit `buero` / `test` oder `admin` / `test`. Das schwarze Fenster offen lassen.

In `config.lokal.php` (wird beim Einrichten angelegt) bei `osm → kontakt` eine eigene E-Mail-Adresse eintragen.

## 3. Mac einrichten (einmalig)

Auf dem Mac liest die App die Access-Datei mit **mdbtools**, ein Access-Treiber ist nicht nötig.

1. **Homebrew** installieren, falls noch nicht vorhanden (Anleitung auf <https://brew.sh>, ein Befehl im Terminal).
   Danach im Terminal:
   ```bash
   brew install php mdbtools
   ```
2. Den entpackten Ordner an einen festen Platz legen, am besten direkt in den **Benutzerordner**
   (z. B. `/Users/lukas/WTG-Wartungsplaner`), **nicht** auf den Schreibtisch, in Dokumente, Downloads oder iCloud.
   Dort darf der Hintergrunddienst (Autostart) aus Datenschutzgründen von macOS nicht zugreifen.
3. **Nur beim ersten Mal**: macOS blockiert Skripte aus dem Internet. Im Terminal einmal:
   ```bash
   cd ~/WTG-Wartungsplaner
   xattr -dr com.apple.quarantine .
   chmod +x *.command
   ```
   (`chmod` ist nötig, wenn die Dateien über die GitHub-Webseite hochgeladen wurden – dabei gehen die Ausführrechte verloren.)
   Ohne Terminal: Rechtsklick auf die `.command`-Datei → **Öffnen** → nochmals **Öffnen**.
4. Access-Datei und Excel-Liste in den Ordner **`Import`** legen.
5. **`1_Einrichten.command`** doppelklicken (Import und Adresssuche, ca. 10 Minuten).
6. **`2_Starten.command`** doppelklicken → `http://localhost:8000`, Anmeldung z. B. `buero` / `test`.
   Soll die App ohne offenes Terminal-Fenster laufen und nach dem Neustart des Mac von selbst wieder da sein:
   einmal **`Autostart einrichten.command`** (rückgängig mit `Autostart entfernen.command`).

## Mac und Windows parallel

- Die Installationen sind **unabhängig**: Jede hat ihre eigene Datenbank im Ordner `daten`.
  Was auf dem MacBook eingetragen wird, steht nicht im Büro-PC und umgekehrt. Für den Test ist das gewollt.
  Für den echten Betrieb gibt es später **eine** Installation auf dem Windows-Server, auf die alle im Browser zugreifen.
- Microsoft 365 funktioniert auf beiden gleich: dieselbe App-Registrierung, dieselbe Umleitungs-URI
  (`http://localhost:8000/…`), die Zugangsdaten jeweils in die eigene `config.lokal.php` eintragen.
  **Aber:** Wenn beide Installationen mit Outlook verbunden sind, tragen beide Termine in dieselben Kalender ein.
  Zum Testen also nur auf **einem** Gerät `outlook_aktiv => true` setzen oder zumindest
  bei allen Mitarbeitern die eigene Adresse eintragen.
- Die Access-Datei enthält Kundendaten. Auf dem privaten MacBook nur mit Freigabe der Firma verwenden
  und nach dem Test aus `Import` und `daten` löschen.

## 4. Microsoft 365 anschließen (echte Outlook-Kalender)

Ohne Microsoft funktioniert alles; Urlaub wird dann in der App eingetragen. Für den echten Anschluss
braucht es eine **App-Registrierung** – dafür sind Administratorrechte im Microsoft-365-Mandanten nötig
(ggf. die IT fragen).

1. <https://entra.microsoft.com> → **App-Registrierungen → Neue Registrierung**
   - Name: `WTG Wartungsplaner`
   - Kontotypen: *Nur Konten in diesem Organisationsverzeichnis*
   - Umleitungs-URI: Plattform **Web**, `http://localhost:8000/login.php?ms=zurueck`
2. Auf der Übersichtsseite **Anwendungs-ID (Client)** und **Verzeichnis-ID (Mandant)** notieren.
3. **Zertifikate & Geheimnisse → Neuer geheimer Clientschlüssel** → den **Wert** sofort kopieren
   (wird nur einmal angezeigt).
4. **API-Berechtigungen → Berechtigung hinzufügen → Microsoft Graph**
   - *Anwendungsberechtigungen*: `Calendars.ReadWrite`
   - *Delegierte Berechtigungen*: `openid`, `profile`, `email` (für „Mit Microsoft anmelden“)
   - danach **Administratorzustimmung erteilen**.
5. **Zugriff auf die Techniker-Postfächer begrenzen** (empfohlen, sonst darf die App in *alle* Kalender
   schreiben). In der Exchange-Online-PowerShell eine E-Mail-aktivierte Sicherheitsgruppe mit den
   Techniker-Postfächern anlegen und:
   ```powershell
   New-ApplicationAccessPolicy -AppId <Client-ID> -PolicyScopeGroupId wtg-techniker@firma.de `
     -AccessRight RestrictAccess -Description "WTG Wartungsplaner nur Techniker"
   ```
6. In **`config.lokal.php`** eintragen:
   ```php
   'microsoft' => [
       'outlook_aktiv' => true,
       'login_aktiv'   => true,
       'tenant_id'     => '…Verzeichnis-ID…',
       'client_id'     => '…Anwendungs-ID…',
       'client_secret' => '…Wert des geheimen Schlüssels…',
   ],
   ```
   `config.lokal.php` steht in `.gitignore` und wird nie hochgeladen.
7. App neu starten, als `admin` anmelden → **Verwaltung**: bei jedem Mitarbeiter die Postfach-Adresse
   eintragen, dann **„Outlook-Postfächer testen“**.

> **Zum Testen** bei allen Mitarbeitern die **eigene** Adresse eintragen – dann landen alle
> Testtermine nur im eigenen Kalender und kein Kollege bekommt Termine.

## 5. Was wo ist

| Bereich | Inhalt |
|---|---|
| Start | Lagebild: was gerade läuft, was fehlt, was noch planbar ist |
| Pflege | Kundenakte, Tickets, Akkus nach Typ, PDF-Ablage, Prüfliste |
| Organisation | Zuweisen, Touren planen, Kalender (Monat/Woche/Tag/Liste), Outlook-Abgleich |
| Meine Termine | Tagesplan mit Karte, Abschluss mit Bericht |
| Auswertung | Fortschritt, Stunden, Auslastung |
| Verwaltung | Benutzer, Mitarbeiter, Auswahllisten, eigene Felder |

Ausführliche Hinweise, Testrundgang und Grenzen des Prototyps: **`LIESMICH.txt`**.

## 6. Updates einspielen

Neue Version herunterladen und die Programmdateien ersetzen. **Nicht** ersetzen bzw. löschen:
den Ordner `daten` (Datenbank und abgelegte PDFs) und `config.lokal.php`.
Neue Felder ergänzt die App beim ersten Start selbst.
