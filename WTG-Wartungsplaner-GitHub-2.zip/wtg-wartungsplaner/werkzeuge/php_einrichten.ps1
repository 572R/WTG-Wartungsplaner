# Stellt die php.ini fuer den WTG Wartungsplaner ein (wird von 0_PHP_einrichten.bat aufgerufen).
# Legt php.ini an, falls sie fehlt, setzt den Erweiterungsordner und schaltet die noetigen Erweiterungen ein.
param([string]$Php)
$ErrorActionPreference = 'Stop'
try {
    $dir = Split-Path -Parent $Php
    $ini = Join-Path $dir 'php.ini'
    if (-not (Test-Path $ini)) {
        $vorlage = Join-Path $dir 'php.ini-production'
        if (-not (Test-Path $vorlage)) { $vorlage = Join-Path $dir 'php.ini-development' }
        if (-not (Test-Path $vorlage)) { Write-Host "  Im Ordner $dir fehlt php.ini-production. Bitte PHP neu als ZIP von windows.php.net entpacken."; exit 1 }
        Copy-Item $vorlage $ini
        Write-Host "  php.ini angelegt: $ini"
    } else {
        Copy-Item $ini "$ini.vorher" -Force
        Write-Host "  php.ini gefunden: $ini (Sicherung: php.ini.vorher)"
    }
    $ext = @('curl', 'mbstring', 'openssl', 'pdo_odbc', 'pdo_sqlite', 'zip')
    $muster = '^\s*(extension_dir\s*=|extension\s*=\s*"?(php_)?(' + ($ext -join '|') + ')(\.dll)?"?\s*$)'
    $zeilen = New-Object System.Collections.Generic.List[string]
    $imBlock = $false
    foreach ($z in [IO.File]::ReadAllLines($ini)) {
        if ($z -eq '; --- WTG Wartungsplaner Anfang ---') { $imBlock = $true; continue }
        if ($z -eq '; --- WTG Wartungsplaner Ende ---') { $imBlock = $false; continue }
        if ($imBlock) { continue }
        if ($z -match $muster) { $z = ';' + $z }   # alte aktive Zeilen ausschalten, damit nichts doppelt geladen wird
        $zeilen.Add($z)
    }
    $zeilen.Add('; --- WTG Wartungsplaner Anfang ---')
    $zeilen.Add('extension_dir = "' + (Join-Path $dir 'ext') + '"')
    foreach ($e in $ext) { $zeilen.Add("extension=$e") }
    $zeilen.Add('; --- WTG Wartungsplaner Ende ---')
    [IO.File]::WriteAllLines($ini, $zeilen, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host '  Erweiterungen eingeschaltet: ' ($ext -join ', ')
    exit 0
} catch {
    Write-Host "  FEHLER: $($_.Exception.Message)"
    Write-Host '  Tipp: Gehoert der PHP-Ordner einem anderen Benutzer? Dann 0_PHP_einrichten.bat per Rechtsklick "Als Administrator ausfuehren".'
    exit 1
}
