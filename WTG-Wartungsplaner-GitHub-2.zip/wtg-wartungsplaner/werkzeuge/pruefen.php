<?php
/**
 * Prüft vor dem Einrichten/Starten, ob PHP alles hat, was die App braucht.
 * Bewusst ohne mb_*-Funktionen, damit die Prüfung auch ohne mbstring läuft.
 * Aufruf: php werkzeuge/pruefen.php [windows|mac]
 */
$sys = $argv[1] ?? (PHP_OS_FAMILY === 'Windows' ? 'windows' : 'mac');
$ini = php_ini_loaded_file();
$fehler = []; $hinweise = [];

if (PHP_VERSION_ID < 80100) $fehler[] = 'PHP ' . PHP_VERSION . ' ist zu alt, bitte PHP 8.2 oder neuer installieren.';
if ($sys === 'windows' && PHP_INT_SIZE < 8) $fehler[] = 'Es ist ein 32-Bit-PHP installiert. Bitte die x64-Version von windows.php.net verwenden.';

$noetig = ['mbstring' => 'Umlaute und Texte', 'pdo_sqlite' => 'Datenbank', 'curl' => 'Karte und Microsoft 365', 'zip' => 'Excel-Liste lesen'];
if ($sys === 'windows') $noetig['pdo_odbc'] = 'Access-Datei lesen';
$fehlt = array_keys(array_filter($noetig, fn($e) => !extension_loaded($e), ARRAY_FILTER_USE_KEY));
if ($fehlt) {
    if ($ini === false) {
        $fehler[] = "PHP findet keine php.ini.\n"
            . "     Im PHP-Ordner " . dirname(PHP_BINARY) . " die Datei php.ini-production kopieren\n"
            . "     und die Kopie php.ini nennen (Dateiendung .ini, nicht .ini.txt!).";
    }
    $fehler[] = "Diese PHP-Erweiterungen fehlen:\n"
        . implode("\n", array_map(fn($e) => "       extension=" . str_pad($e, 12) . "(" . $noetig[$e] . ')', $fehlt)) . "\n"
        . "     In " . ($ini ?: 'php.ini') . " bei diesen Zeilen das ; am Zeilenanfang entfernen und speichern.";
}

// Access-Treiber (nur Windows, nur wenn pdo_odbc da ist)
if ($sys === 'windows' && extension_loaded('pdo_odbc')) {
    try { new PDO('odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};Dbq=' . sys_get_temp_dir() . '\\gibt-es-nicht.accdb'); }
    catch (Throwable $e) {
        if (stripos($e->getMessage(), 'IM002') !== false || stripos($e->getMessage(), 'Datenquellenname') !== false || stripos($e->getMessage(), 'data source name') !== false)
            $fehler[] = "Der Microsoft-Access-Treiber (64-Bit) fehlt.\n"
                . "     Bitte die \"Microsoft Access Database Engine 2016 Redistributable\" in der x64-Version installieren\n"
                . "     (bei installiertem 32-Bit-Office: accessdatabaseengine_X64.exe /quiet) - siehe README.";
    }
}

$ordner = dirname(__DIR__);
if (stripos($ordner, 'OneDrive') !== false || stripos($ordner, 'SharePoint') !== false || stripos($ordner, 'Dropbox') !== false)
    $hinweise[] = "Der Ordner liegt in OneDrive/SharePoint:\n     $ordner\n"
        . "     Die Datenbank (Ordner daten) kann durch die Synchronisierung beschädigt werden, und Kundendaten\n"
        . "     landen in der Cloud. Besser den ganzen Ordner z. B. nach C:\\WTG-Wartungsplaner verschieben.";
if (!is_writable($ordner)) $fehler[] = "In den Ordner $ordner darf nicht geschrieben werden.";

echo "\n  PHP " . PHP_VERSION . ' (' . (PHP_INT_SIZE * 8) . ' Bit), php.ini: ' . ($ini ?: 'KEINE') . "\n";
foreach ($hinweise as $h) echo "\n  HINWEIS: $h\n";
if ($fehler) {
    echo "\n  Bevor es losgehen kann:\n";
    foreach ($fehler as $i => $f) echo "\n  " . ($i + 1) . ". $f\n";
    echo "\n  Danach dieses Fenster schließen und erneut doppelklicken.\n\n";
    exit(1);
}
echo "  Prüfung in Ordnung.\n\n";
