@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo  PHP fuer den WTG Wartungsplaner einstellen
echo  ------------------------------------------
rem php.exe suchen: zuerst C:\php, sonst aus dem PATH
set "PHP=C:\php\php.exe"
if not exist "%PHP%" for /f "delims=" %%p in ('where php 2^>nul') do if not defined PHPGEF set "PHPGEF=%%p"
if not exist "%PHP%" if defined PHPGEF set "PHP=%PHPGEF%"
if not exist "%PHP%" (
  echo  PHP nicht gefunden. Bitte PHP ^(x64, ZIP^) von windows.php.net nach C:\php entpacken - siehe README.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "werkzeuge\php_einrichten.ps1" -Php "%PHP%"
if errorlevel 1 (
  pause
  exit /b 1
)
"%PHP%" werkzeuge\pruefen.php windows
if errorlevel 1 (
  pause
  exit /b 1
)
echo  Jetzt 1_Einrichten doppelklicken.
pause
